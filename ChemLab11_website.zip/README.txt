ChemLab 11 website prototype

Open index.html in a browser.

Included:
- Home page
- Class 11 Chemistry chapter cards
- Interactive VSEPR demo
- 30-day ₹30 membership UI
- Payment placeholder (no real payment processing)

Next development step:
Replace the demo VSEPR graphic with your own 3D simulations and connect a compliant payment/subscription backend. Because the site involves paid access, use a parent/guardian or other adult to handle payment-provider accounts and payouts if required.
